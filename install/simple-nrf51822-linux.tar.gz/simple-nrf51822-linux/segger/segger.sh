#!/bin/bash


cd /opt/JLink_Linux_V462a
./StartJLinkExe.sh $*
